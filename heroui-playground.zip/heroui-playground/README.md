# HeroUI Playground

Real HeroUI + React playground for GitHub Pages.

## Mobile GitHub setup

1. Extract this zip.
2. Upload all extracted files and folders to a new GitHub repository.
3. Go to Settings > Pages.
4. Set Source to GitHub Actions.
5. Open the Actions tab and wait for the deploy to finish.

No local npm is needed. GitHub Actions builds the project online.
