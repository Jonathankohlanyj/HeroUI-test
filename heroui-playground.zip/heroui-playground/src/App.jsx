import {
  Accordion,
  AccordionItem,
  Avatar,
  Badge,
  Button,
  Card,
  CardBody,
  CardHeader,
  Checkbox,
  Chip,
  Divider,
  Input,
  Progress,
  Select,
  SelectItem,
  Slider,
  Spinner,
  Switch,
  Textarea,
} from "@heroui/react";

export default function App() {
  return (
    <main className="min-h-screen bg-background text-foreground p-4 sm:p-6">
      <section className="mx-auto flex max-w-6xl flex-col gap-6">
        <header className="rounded-[2rem] border border-white/10 bg-gradient-to-br from-zinc-900 to-zinc-950 p-6 shadow-2xl">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
            <div className="space-y-3">
              <Chip color="primary" variant="flat">Real HeroUI + React</Chip>
              <h1 className="text-4xl font-black tracking-tight sm:text-6xl">HeroUI Playground</h1>
              <p className="max-w-2xl text-base text-default-500 sm:text-lg">
                A mobile-friendly playground with real HeroUI components, built by GitHub Actions and published on GitHub Pages.
              </p>
            </div>
            <Badge content="9+" color="danger" placement="top-right">
              <Avatar className="h-20 w-20 text-2xl" color="primary" name="H" />
            </Badge>
          </div>
        </header>

        <section className="grid gap-4 md:grid-cols-3">
          <Card className="border border-white/10 bg-content1/80">
            <CardHeader className="flex gap-3">
              <Chip color="primary">01</Chip>
              <div>
                <h2 className="font-bold">Buttons</h2>
                <p className="text-small text-default-500">Variants and colors</p>
              </div>
            </CardHeader>
            <Divider />
            <CardBody className="flex flex-wrap gap-3">
              <Button color="primary">Primary</Button>
              <Button color="secondary">Secondary</Button>
              <Button color="success">Success</Button>
              <Button color="warning">Warning</Button>
              <Button color="danger">Danger</Button>
              <Button variant="bordered">Bordered</Button>
              <Button variant="flat" color="primary">Flat</Button>
              <Button isLoading color="primary">Loading</Button>
            </CardBody>
          </Card>

          <Card className="border border-white/10 bg-content1/80">
            <CardHeader className="flex gap-3">
              <Chip color="secondary">02</Chip>
              <div>
                <h2 className="font-bold">Inputs</h2>
                <p className="text-small text-default-500">Forms and controls</p>
              </div>
            </CardHeader>
            <Divider />
            <CardBody className="gap-4">
              <Input label="Username" placeholder="Type here" />
              <Input label="Email" placeholder="you@example.com" type="email" />
              <Textarea label="Message" placeholder="Write something cool" />
              <Select label="Framework" defaultSelectedKeys={["react"]}>
                <SelectItem key="react">React</SelectItem>
                <SelectItem key="vite">Vite</SelectItem>
                <SelectItem key="heroui">HeroUI</SelectItem>
              </Select>
            </CardBody>
          </Card>

          <Card className="border border-white/10 bg-content1/80">
            <CardHeader className="flex gap-3">
              <Chip color="success">03</Chip>
              <div>
                <h2 className="font-bold">Status</h2>
                <p className="text-small text-default-500">Progress and feedback</p>
              </div>
            </CardHeader>
            <Divider />
            <CardBody className="gap-5">
              <div className="flex items-center gap-3">
                <Spinner color="primary" />
                <Chip color="success" variant="flat">Online</Chip>
                <Chip color="warning" variant="flat">Building</Chip>
              </div>
              <Progress label="Build progress" value={82} color="primary" />
              <Slider label="Power level" defaultValue={68} />
              <Switch defaultSelected>Dark mode energy</Switch>
              <Checkbox defaultSelected>Enable chaos mode</Checkbox>
            </CardBody>
          </Card>
        </section>

        <Card className="border border-white/10 bg-content1/80">
          <CardHeader>
            <div>
              <h2 className="text-2xl font-bold">Component Notes</h2>
              <p className="text-default-500">A small accordion section to prove more components are working.</p>
            </div>
          </CardHeader>
          <Divider />
          <CardBody>
            <Accordion variant="splitted">
              <AccordionItem key="1" aria-label="Real package" title="Is this real HeroUI?">
                Yes. This imports components from @heroui/react and styles from @heroui/styles.
              </AccordionItem>
              <AccordionItem key="2" aria-label="Mobile deploy" title="Does this work from mobile?">
                Yes. Upload the project to GitHub, enable Pages with GitHub Actions, and GitHub builds it for you.
              </AccordionItem>
              <AccordionItem key="3" aria-label="No local npm" title="Do I need npm on my phone?">
                No. GitHub Actions runs npm install and npm run build online.
              </AccordionItem>
            </Accordion>
          </CardBody>
        </Card>
      </section>
    </main>
  );
}
